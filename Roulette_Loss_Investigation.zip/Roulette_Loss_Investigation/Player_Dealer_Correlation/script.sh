#1/bin/bash
grep -i '05:00:00 AM' 03*.txt | awk '{print $1,$2,$5,$6}'
grep -i '08:00:00 AM' 03*.txt | awk '{print $1,$2,$5,$6}'
grep -i '02:00:00 PM' 03*.txt | awk '{print $1,$2,$5,$6}'
grep -i '08:00:00 PM' 0310*.txt 0312*.txt | awk '{print $1,$2,$5,$6}'
grep -i '11:00:00 PM' 0310*.txt 0312*.txt | awk '{print $1,$2,$5,$6}'




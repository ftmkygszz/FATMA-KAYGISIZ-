#!/bin/bash
cat 03*.txt | awk '{print $1,$2,$5,$6}'

cat Dealers_working_during_losses.txt | awk '{print $1,$2}'

